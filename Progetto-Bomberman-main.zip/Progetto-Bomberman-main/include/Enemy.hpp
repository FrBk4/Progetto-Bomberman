#ifndef ENEMY_HPP
#define ENEMY_HPP

enum EnemyType {
    SLOW,
    FAST
};

class Enemy {
private:
    int x;
    int y;
    EnemyType type;

public:
    Enemy(int startX, int startY, EnemyType type);

    int getX() const;
    int getY() const;
    EnemyType getType() const;
    bool isAtPosition(int otherX, int otherY) const;


    void move();
};

#endif
