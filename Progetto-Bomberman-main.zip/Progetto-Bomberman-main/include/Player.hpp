#ifndef PLAYER_HPP
#define PLAYER_HPP

class Player {
private:
    int x;
    int y;
    int lives;
    int score = 0;

public:
    Player(int startX, int startY);

    int getX() const;
    int getY() const;
    int getLives() const;
    bool isAtPosition(int otherX, int otherY) const;
    void setPosition(int y, int x);
    int getScore() const;
    void addScore(int s);
    void move(int dx, int dy);
    void setLives(int l);
    void loseLife();

};

#endif