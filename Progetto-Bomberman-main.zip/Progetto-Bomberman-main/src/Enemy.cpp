#include "../include/Enemy.hpp"

Enemy::Enemy(int startX, int startY, EnemyType t)
    : x(startX), y(startY), type(t) {}

int Enemy::getX() const {
    return x;
}

int Enemy::getY() const {
    return y;
}

EnemyType Enemy::getType() const {
    return type;
}

void Enemy::move() {
    if (type == SLOW) {
        x += 1;
    } else {
        x += 2;
    }
}

bool Enemy::isAtPosition(int otherX, int otherY) const {
    return x == otherX && y == otherY;
}