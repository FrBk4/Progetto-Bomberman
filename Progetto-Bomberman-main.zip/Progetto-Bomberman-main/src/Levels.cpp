#include <iostream>
#include <ctime>
#include <string>
#include <curses.h>
#include "../include/Levels.hpp"
#include "../include/Player.hpp"
#include "../include/Items.hpp"
#include "../include/Score.hpp"

#define DESTR_RATIO (10+(node->index*4))
#define ITEMS_RATIO (node->index+2)

using namespace std;

Itemlist items;
Player p(1, 1);

map* Levels::genlevels() {

    map* head = nullptr;
    map* prev = nullptr;

    // ===== CREAZIONE LIVELLI =====
    for (int liv = 0; liv < 5; liv++) {
        map* node = new map;

        node->index = liv;
        node->previous = prev;
        node->next = nullptr;

        for (int y = 0; y < 23; y++) {
            for (int x = 0; x < 43; x++) {

                // muri indistruttibili a griglia
                if (x % 2 == 0 && y % 2 == 0)
                    node->level[y][x] = '#';
                else
                    node->level[y][x] = ' ';

                // bordo mappa
                if (x == 0 || y == 0 || x == 42 || y == 22)
                    node->level[y][x] = '#';
            }
        }

        if (prev)
            prev->next = node;
        else
            head = node;

        prev = node;
    }

    srand(time(nullptr));

    // ===== MURI DISTRUTTIBILI =====
    for (map* node = head; node; node = node->next) {
        int prob = 10 + node->index * 4;

        for (int y = 1; y < 22; y++) {
            for (int x = 1; x < 42; x++) {

                if (node->level[y][x] == ' ' && (x > 5 || y > 5)) {
                    if (rand() % 100 < prob)
                        node->level[y][x] = '+';
                }
            }
        }
    }

    // ===== ITEM =====
    for (map* node = head; node; node = node->next) {
        for (int y = 1; y < 22; y++) {
            for (int x = 1; x < 42; x++) {

                if (node->level[y][x] == ' ' && (x > 5 || y > 5)) {
                    char it = items.spawnrate(node->index + 2);
                    if (it != ' ')
                        node->level[y][x] = it;
                }
            }
        }
    }

    // ===== PORTE LIVELLI =====
    for (map* node = head; node; node = node->next) {
        if (node->index != 0)
            node->level[1][0] = '<';     // torna indietro
        if (node->index != 4)
            node->level[21][42] = '>';  // vai avanti
    }

    // ===== NEMICI (ULTIMA COSA!) =====
    for (map* node = head; node; node = node->next) {

        int placed = 0;

        for (int y = 1; y < 22 && placed < 5; y++) {
            for (int x = 1; x < 42 && placed < 5; x++) {

                if (node->level[y][x] == ' ') {
                    int r = rand() % 100;

                    if (r < 5) {              // nemico lento
                        node->level[y][x] = 'N';
                        placed++;
                    }
                    else if (r == 99) {       // nemico veloce
                        node->level[y][x] = 'M';
                        placed++;
                    }
                }
            }
        }
    }

    return head;
}


WINDOW* Levels::enclose_screen(map* map, int time_left, int lvl) {  //questa funzione mostra su schermo la mappa (inizialmente livello 1)

    int x_offset = getmaxx(stdscr) / 2 - 21;
    if (x_offset < 0) x_offset = 0;

    WINDOW * screen = newwin(25, 45, 3, x_offset);

    for (int y=0; y<23; y++)
        for(int x=0; x<43; x++) {
            mvwprintw(screen, y+1, x+1, "%c", map->level[y][x]);
        }

    items.hideitems(map, screen);

    wborder(screen,  186, 186,
                     205, 205,
                     201, 187,
                     200, 188);

    mvwprintw(screen, 24, 29, "Tempo: %ds", time_left);
    mvwprintw(screen, 24, 3, "Punti: %d",p.getScore());
    mvwprintw(screen, 24, 16, "Vite: %d",p.getLives());
    mvwprintw(screen, 0, 17, "Livello: %d", lvl+1);

    wrefresh(screen);

    return screen;
}

//----------------------------------------------------------------------------------------------------------------------

void Levels::run() {
    clear();
    refresh();

    time_t start = time(nullptr);
    time_t time_left = 1000;

    Map = genlevels();
    map* current_level = Map;

    p.setPosition(1, 1);

    WINDOW* screen = enclose_screen(current_level, (int)time_left, 0);
    keypad(screen, true);
    nodelay(screen, TRUE);

    bool ingame = true;
    int levelNumber = 1;

    // ===== BOMBA =====
    bool bombPlaced = false;
    int bombX = -1, bombY = -1;
    time_t bombTime = 0;
    int bombRadius = 2;

    // ===== ESPLOSIONE VISIVA  =====
    bool explosionVisible = false;
    time_t explosionTime = 0;
    int explosionX[32];
    int explosionY[32];
    int explosionCount = 0;

    // ===== INVINCIBILITÀ =====
    bool invincible = false;
    time_t invStart = 0;

    while (ingame) {

        int ch = wgetch(screen);
        if (ch == ERR) ch = 0;
        napms(120);

        int dx = 0, dy = 0;

        // ===== INPUT =====
        switch (ch) {
            case 27:
                ingame = false;
                continue;

            case 'w': case 'W': case KEY_UP:    dy = -1; break;
            case 's': case 'S': case KEY_DOWN:  dy =  1; break;
            case 'a': case 'A': case KEY_LEFT:  dx = -1; break;
            case 'd': case 'D': case KEY_RIGHT: dx =  1; break;

            case 'e': case 'E': if (!bombPlaced && current_level->level[p.getY()][p.getX()] == ' ') {
                                    bombPlaced = true;
                                    bombX = p.getX();
                                    bombY = p.getY();
                                    bombTime = time(nullptr);
                                    current_level->level[bombY][bombX] = 'B';
                                }

            break;
        }

        // ===== MOVIMENTO PLAYER =====
        if (dx || dy) {
            int nx = p.getX() + dx;
            int ny = p.getY() + dy;

            char next = current_level->level[ny][nx];
            if (next != '#' && next != '+') {
                p.move(dx, dy);
            }
        }

        // ===== PICKUP POWER-UP =====
        char &cellItem = current_level->level[p.getY()][p.getX()];
        if (cellItem >= 'A' && cellItem <= 'Z') {

            int lives = p.getLives();
            int radius = bombRadius;
            time_t effectStart = time(nullptr);

            items.effect_list(
                cellItem,
                &lives,
                current_level,
                screen,
                effectStart,
                &effectStart,
                &radius
            );

            p.setLives(lives);
            bombRadius = radius;
            cellItem = ' ';
        }


        if (invincible && time(nullptr) - invStart >= 1)
            invincible = false;

        // ===== ESPLOSIONE BOMBA (LOGICA + CELLE) =====
        if (bombPlaced && time(nullptr) - bombTime >= 2) {

            explosionCount = 0;

            // centro
            explosionX[explosionCount] = bombX;
            explosionY[explosionCount] = bombY;
            explosionCount++;

            current_level->level[bombY][bombX] = ' ';

            int dx4[4] = {1, -1, 0, 0};
            int dy4[4] = {0, 0, 1, -1};

            for (int d = 0; d < 4; d++) {
                for (int r = 1; r <= bombRadius; r++) {

                    int ny = bombY + dy4[d] * r;
                    int nx = bombX + dx4[d] * r;
                    if (ny < 0 || ny >= 22 || nx < 0 || nx >= 42)
                        break;
                    char &c = current_level->level[ny][nx];

                    if (c == '#')
                        break;

                    if (explosionCount < 32) {
                        explosionX[explosionCount] = nx;
                        explosionY[explosionCount] = ny;
                        explosionCount++;
                    }

                    if (c == '+') {
                        c = ' ';
                        p.addScore(20);
                        break;
                    }

                    if (c == 'N' || c == 'M') {
                        c = ' ';
                        p.addScore(100);
                    }
                }
            }

            explosionVisible = true;
            explosionTime = time(nullptr);
            bombPlaced = false;
        }

        // ===== MOVIMENTO NEMICI =====
        for (int y = 1; y < 22; y++) {
            for (int x = 1; x < 42; x++) {
                char enemy = current_level->level[y][x];
                if (enemy == 'N' || enemy == 'M') {

                    int dir = rand() % 4;
                    int nx = x, ny = y;

                    if (dir == 0) ny--;
                    if (dir == 1) ny++;
                    if (dir == 2) nx--;
                    if (dir == 3) nx++;

                    if (current_level->level[ny][nx] == ' ') {
                        current_level->level[ny][nx] = enemy;
                        current_level->level[y][x] = ' ';
                        x++;
                    }
                }
            }
        }

        char cellAfter = current_level->level[p.getY()][p.getX()];
        if ((cellAfter == 'N' || cellAfter == 'M') && !invincible) {
            p.loseLife();
            invincible = true;
            invStart = time(nullptr);
        }


        // ===== COLLISIONE PLAYER - NEMICO =====
        char cell = current_level->level[p.getY()][p.getX()];
        if ((cell == 'N' || cell == 'M') && !invincible) {
            p.loseLife();
            invincible = true;
            invStart = time(nullptr);
        }

        bool enemiesLeft = false;
        for (int y = 0; y < 22; y++)
            for (int x = 0; x < 42; x++)
                if (current_level->level[y][x] == 'N' ||
                    current_level->level[y][x] == 'M')
                    enemiesLeft = true;
                
        if (!enemiesLeft && current_level->next) {
            current_level = current_level->next;
            levelNumber++;
        
            p.setPosition(1, 1);
        
            delwin(screen);
            screen = enclose_screen(current_level, (int)time_left, 0);
            keypad(screen, true);
            nodelay(screen, TRUE);
        
            continue;
        }



        // ===== RENDER =====
        werase(screen);
        box(screen, 0, 0);

        mvwprintw(screen, 24, 3,  "Punti: %d", p.getScore());
        mvwprintw(screen, 24, 16, "Vite: %d",  p.getLives());
        mvwprintw(screen, 24, 29, "Tempo: %d", (int)time_left);
        mvwprintw(screen, 0, 2,   "Livello: %d", levelNumber);


        for (int y = 0; y < 22; y++)
            for (int x = 0; x < 42; x++)
                mvwprintw(screen, y + 1, x + 1, "%c", current_level->level[y][x]);


        // esplosione visiva
        if (explosionVisible) {
            for (int i = 0; i < explosionCount; i++)
                mvwprintw(screen,
                          explosionY[i] + 1,
                          explosionX[i] + 1,
                          "*");

            if (time(nullptr) - explosionTime >= 1)
                explosionVisible = false;
        }

        // player
        if (!invincible || time(nullptr) % 2 == 0)
            mvwprintw(screen, p.getY() + 1, p.getX() + 1, "@");

        // HUD
        time_t now = time(nullptr);
        time_left -= (now - start);
        start = now;

        mvwprintw(screen, 24, 3,  "Punti: %d", p.getScore());
        mvwprintw(screen, 24, 16, "Vite: %d",  p.getLives());
        mvwprintw(screen, 24, 29, "Tempo: %d", (int)time_left);

        if (p.getLives() <= 0 || time_left <= 0)
            ingame = false;

        wrefresh(screen);
    }

    // ===== GAME OVER =====
    echo();
    nocbreak();
    nodelay(screen, false);

    char name[32];
    WINDOW* prompt = newwin(5, 40,
        getmaxy(stdscr)/2 - 2,
        getmaxx(stdscr)/2 - 20);

    box(prompt, 0, 0);
    mvwprintw(prompt, 1, 2, "Game Over!");
    mvwprintw(prompt, 2, 2, "Inserisci il tuo nome:");
    wrefresh(prompt);

    wgetnstr(prompt, name, 31);
    Score::saveScore("scores.txt", name, p.getScore());

    delwin(prompt);
    noecho();
    cbreak();

    clear();
    refresh();

    map* tmp;
    while (Map) {
        tmp = Map;
        Map = Map->next;
        delete tmp;
    }

    delwin(screen);
}
