#include "../include/Game.hpp"

int main() {
    Game game;
    game.run();
    return 0;
}
